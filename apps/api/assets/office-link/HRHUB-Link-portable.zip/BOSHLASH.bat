@echo off
REM HR HUB Link — ofis ilovasini ochish
cd /d "%~dp0"
if exist "%~dp0ilova\HRHUB-Qurilma.exe" (
  start "" /D "%~dp0ilova" "%~dp0ilova\HRHUB-Qurilma.exe"
  exit /b 0
)
echo HRHUB-Qurilma.exe topilmadi. ilova\ papkasini tekshiring.
pause
exit /b 1
