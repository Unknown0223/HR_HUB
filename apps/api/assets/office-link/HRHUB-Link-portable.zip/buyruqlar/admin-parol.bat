@echo off
cd /d "%~dp0.."
call "%~dp0..\ADMIN-PAROL.bat"
