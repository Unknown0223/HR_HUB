@echo off
cd /d "%~dp0.."
if exist "%CD%\data\tunnel_url.txt" (type "%CD%\data\tunnel_url.txt") else echo Tunnel URL yo'q.
pause
