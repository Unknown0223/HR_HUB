@echo off
cd /d "%~dp0.."
sc query HRHUB-OfficeLink 2>nul
if exist "%CD%\data\service_status.json" type "%CD%\data\service_status.json"
if exist "%CD%\data\tunnel_url.txt" type "%CD%\data\tunnel_url.txt"
pause
