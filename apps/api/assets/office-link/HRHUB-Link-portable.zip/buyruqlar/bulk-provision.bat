@echo off
cd /d "%~dp0.."
if "%~1"=="" (
  echo Foydalanish: buyruqlar\bulk-provision.bat --hosts IP1,IP2 --location ID --password PAROL
  pause
  exit /b 1
)
python "%~dp0..\bulk_provision.py" %*
pause
