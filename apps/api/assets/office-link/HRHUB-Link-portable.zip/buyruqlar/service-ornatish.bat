@echo off
cd /d "%~dp0.."
call "%~dp0..\install-service.bat"
